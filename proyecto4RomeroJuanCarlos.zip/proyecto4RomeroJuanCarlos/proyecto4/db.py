MYSQL = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME':  'bdproyecto4',
        'USER':'usuario',
        'PASSWORD':'usuario',
        'PORT':'3306'
    }
}