from django.apps import AppConfig


class Pruebamod1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pruebamod1'
