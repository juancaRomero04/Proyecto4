from django.apps import AppConfig


class Pruebamod2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pruebamod2'
